


```erl
c(tpri_app), c(tpri_server), c(tpri_sup).
```


```erl
c(trm_sup), c(trm_worker).
```

```erl
c(imp_sup), c(imp_acker), c(imp_msger).
```



```erl
tpri:start().
```
